class Calendar {
    constructor() {
        //this.date = new Date(month = null, year = null)
        this.moment = moment.locale('de')
    }

    static initialize() {
        this.moment = moment()
        this.moment.locale('fr')
        console.log(this.moment.format('YYYY MMMM dddd'))
    }

    static render(parent) {

    }
}