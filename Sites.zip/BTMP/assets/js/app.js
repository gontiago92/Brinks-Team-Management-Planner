(function() {
  
    let dropdownMenuLink = document.querySelectorAll('.dropdown-toggle')
        
    for(let i = 0; i < dropdownMenuLink.length; i++) {
        dropdownMenuLink[i].addEventListener('click', function(e) {
        e.preventDefault()
        e.stopPropagation()

        let visible = document.querySelector('[data-hidden="false"]')
        if(visible) {
            Dropdown.fadeOut(visible)
        }

        let dropdownMenu = this.nextElementSibling

        Dropdown.fadeToggle(dropdownMenu)

        })
    } 

    document.addEventListener('click', function() {
        let visibleElements = document.querySelectorAll('[data-hidden="false"]')
        for(let i = 0; i < visibleElements.length; i++) {
        if(visibleElements[i] != null) {
            Dropdown.fadeOut(visibleElements[i])
        }
        }
    })

})()

const logo = document.getElementById('logo')
const paths = logo.querySelectorAll('path')

for (let index = 0; index < paths.length; index++) {
    const element = paths[index];
    const size = element.getTotalLength()

    element.style.strokeDasharray = size
    element.style.strokeDashoffset = size

    element.style.animation = 'line-anim 2s forwards ' + (index / 4) + 's'

    setTimeout(() => { 
        element.animate([
            // keyframes
            { fill: 'transparent'},
            { fill: '#111319' }
        ], {
            // timing options
            fill: "forwards",
            duration: 1000,
            delay: index / 4 * 1000
        })
    }, 1500)
}

Calendar.initialize()