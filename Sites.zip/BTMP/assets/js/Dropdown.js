class Dropdown {
    static fadeOut(element) {
        element.style.opacity = "0"
        setTimeout(function() {
            element.parentNode.style.overflow = "hidden"
            element.style.display = "none"
            element.setAttribute('data-hidden', true)
        }, 400)
    }
    static fadeIn(element) {
        element.style.display = "block"
        element.offsetWidth
        element.parentNode.style.overflow = "visible"
        element.style.opacity = "1"
        element.setAttribute('data-hidden', false)
    }
    static fadeToggle(element) {
        let hidden = element.getAttribute('data-hidden')
        if(hidden === 'true') { 
            this.fadeIn(element)
        } else {  
            this.fadeOut(element)
        }
    }
}

