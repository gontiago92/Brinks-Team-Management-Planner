import { Calendar } from './Calendar.js'

const calendar = new Calendar()

console.log(calendar.render())
