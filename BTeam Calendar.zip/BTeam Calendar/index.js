import { Calendar } from './Calendar.js'

const calendar = new Calendar(document.getElementById('calendar'))

calendar.render()
