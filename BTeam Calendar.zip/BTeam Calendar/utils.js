export function createComponent(type, classList = null) {
    const element = document.createElement(type)
    if(classList != null)
        element.setAttribute('class', classList)

    return element
}
