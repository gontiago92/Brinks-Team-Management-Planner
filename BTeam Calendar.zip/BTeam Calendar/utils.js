export function createComponent(type, classList = null, content = null) {
    const element = document.createElement(type)
    if(classList != null)
        element.setAttribute('class', classList)

    if (content)
        element.append(content)

    return element
}
