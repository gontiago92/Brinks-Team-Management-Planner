import {createComponent} from "./utils.js";

export class Calendar {
    constructor(element) {
        this.calendar = element
        this.moment = moment()
        this.now = this.moment.locale('fr')
        this.startDay = this.now.clone().startOf('month').startOf('week')
        this.endDay = this.now.clone().endOf('month').endOf('week')
        this.day = this.startDay.clone().subtract(1, 'day')

        window.addEventListener('resize', () => {
            return this.renderWeekdays()
        })
    }

    render() {
        const calendar = this.getDays()
        this.calendar.childNodes.forEach(child => child.remove())
        calendar.map(week => {

            const weekComponent = createComponent('div', 'week-'+ calendar.length)

            week.map(day =>  {
                const dayComponent = createComponent('div', 'day')
                this.now.isSame(day, 'day') ? dayComponent.classList.add('today') : ''
                dayComponent.append(day.format('DD'))

                weekComponent.append(dayComponent)
            })


            this.calendar.insertAdjacentElement('beforeend', weekComponent)


        })
        this.renderCurrentMonth()
        this.renderWeekdays()
    }

    getDays() {

        const calendar = []

        while(this.day.isBefore(this.endDay, 'day')) {
            calendar.push(
                Array(7)
                    .fill(0)
                    .map(() => this.day.add(1, 'day').clone())
            )
        }

        return calendar
    }

    renderWeekdays() {
        const weekdays = (window.innerWidth > 800 ? this.now.localeData().weekdays(true) : this.now.localeData().weekdaysShort(true))
        const weekdaysComponent = createComponent('div', 'weekdays')

        weekdays.map(weekday => {
            //weekday = weekday[0].toUpperCase() + weekday.substr(1, weekday.length)
            const day = `<div class="weekday">${weekday}</div>`
            weekdaysComponent.insertAdjacentHTML('beforeend', day)
        })

        this.calendar.querySelector('.weekdays') != undefined ? this.calendar.querySelector('.weekdays').remove() : ''
        this.calendar.insertBefore(weekdaysComponent, document.querySelector('.header').nextElementSibling)
        console.log('RENDERED')
    }

    renderCurrentMonth() {
        const headerComponent = createComponent('div', 'header')
        const monthDisplayComponent = createComponent('h1', 'monthDisplay')
        monthDisplayComponent.append(this.now.format('MMMM YYYY'))
        headerComponent.append(monthDisplayComponent)

        this.calendar.insertAdjacentElement('afterbegin', headerComponent)
        this.initButtons(headerComponent)
    }

    initButtons(container) {
        const prevButton = createComponent('button', 'prev')
        const nextButton = createComponent('button', 'next')
        prevButton.innerHTML = '<i class="fa fa-chevron-left"></i>'
        nextButton.innerHTML = '<i class="fa fa-chevron-right"></i>'
        prevButton.addEventListener('click', e => this.prev())
        nextButton.addEventListener('click', e => this.next())

        container.insertAdjacentElement('afterbegin', prevButton)
        container.insertAdjacentElement('beforeend', nextButton)
    }

    prev() {

        this.now = this.now.clone().subtract(1, 'month')
        this.render()
    }

    next() {

        this.now = this.now.clone().add(1, 'month')
        this.render()
    }
}
