import {createComponent} from "./utils.js";

export class Calendar {
    constructor() {
        this.moment = moment()
        this.now = this.moment.locale('fr')
        this.startDay = this.now.clone().startOf('month').startOf('week')
        this.endDay = this.now.clone().endOf('month').endOf('week')
        this.day = this.startDay.clone().subtract(1, 'day')
    }

    render() {
        const calendar = this.getDays()

        calendar.map(week => {
            const weekComponent = createComponent('div', 'week')

            week.map(days => console.log(days))
        })
        console.log(createComponent('div'))
    }

    getDays() {
        const calendar = []

        while(this.day.isBefore(this.endDay, 'day')) {
            calendar.push(
                Array(7)
                    .fill(0)
                    .map(() => this.day.add(1, 'day').clone())
            )
        }

        return calendar
    }
}
