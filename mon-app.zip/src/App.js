import './App.css';
import Calendar from './components/calendar'


function App() {
  return <Calendar />
}

export default App;
