export function Day({onClick, className, day}) {
    return <div onClick={onClick} className={'day ' + className}>
        <div>{day}</div>
    </div>
}

export function WeekDays({weekdays}) {
    return <div className="weekdays">
        {
            weekdays.map((weekday, k) => <div key={k} className="weekday">
                {weekday}
            </div>)
        }
    </div>
}