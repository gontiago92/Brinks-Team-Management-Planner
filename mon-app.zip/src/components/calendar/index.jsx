import React, { useEffect, useState } from 'react'
import moment from 'moment'
import {Day, WeekDays} from './calendar-helpers'
import './styles.css'


function Calendar() {
    const [calendar, setCalendar] = useState([])
    const momentum = moment().locale('fr')
    const [value, setValue] = useState(momentum)
    
    const startDay = value.clone().startOf('month').startOf('week')
    const endDay = value.clone().endOf('month').endOf('week')
    const day = startDay.clone().subtract(1, 'day')

    useEffect(() => {
        const cal = []
        while(day.isBefore(endDay, 'day')) {
            cal.push(
                Array(7).fill(0).map(() => day.add(1, 'day').clone())
            )
        }
        setCalendar(cal)
    }, [value])

    function isToday(day) {
        return day.isSame(new Date(), 'day')
    }

    return <div className="calendar">
        <div className="header">
            <h1 className="monthDisplay">MonthDisplay</h1>
        </div>
        
        <WeekDays weekdays={value.localeData().weekdays(true)}/>
        {
            calendar.map((week, k) => <div key={k} className={'week-' + calendar.length}>{

                week.map((day, k) =>
                    
                    <Day 
                    className={(isToday(day) ? 'today ' : '') + (value.isSame(day, 'day') ? 'selected' : '')} 
                    selected="de"
                    key={k} 
                    day={day.format('DD').toString()}
                    onClick={() => setValue(day)}
                    />
                )

            }</div>)
        }
    </div>
}

export default Calendar